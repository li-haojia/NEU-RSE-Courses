# No.2
# MLP
# 姓名:李昊佳
from sklearn.datasets import load_iris
from sklearn.neural_network import MLPClassifier

import numpy as np
import matplotlib.pyplot as plt

train_ratio=0.7

iris = load_iris()

X = np.array(iris.data)
Y = np.array(iris.target)
#注意打乱数据集，不然传入的数据不全
rand_ind=np.random.permutation(X.shape[0])
X_rand=X[rand_ind]
Y_rand=Y[rand_ind]

train_num=int(X.shape[0]*train_ratio)
train_dataset=X_rand[:train_num]
train_target=Y_rand[:train_num]
print("训练集大小:",train_dataset.shape[0])
#测试数据集
test_dataset=X_rand[train_num:]
test_target=Y_rand[train_num:]
test_num=test_dataset.shape[0]
print("测试集大小:",test_dataset.shape[0])

clf = MLPClassifier(solver='adam', activation='logistic', learning_rate_init=0.01,alpha=1e-4, hidden_layer_sizes=(10,8),max_iter=1000,random_state=1)

clf.fit(train_dataset,train_target)
result=clf.predict(test_dataset)

right_arr=np.empty(test_dataset.shape[0],dtype='bool')
right_arr=(result==test_target)

right_num=np.count_nonzero(right_arr)
print("准确度:",right_num/test_num)


right_x=test_dataset[right_arr==True]
wrong_x=test_dataset[right_arr==False]


plt.figure()
plt.scatter(right_x[:,2],right_x[:,3],label="True")
plt.scatter(wrong_x[:,2],wrong_x[:,3],label="False")
plt.xlabel("length")
plt.ylabel("width")
plt.legend()
plt.show()
