# No.1
# MLP
# 姓名:李昊佳
from sklearn.neural_network import MLPClassifier


train_x = [[0, 0],[0,1],[1,1],[1, 0]]
train_y = [1,0,1,0]

test_x = [[0,1],[1,0],[0,1],[1,1]]
test_y = [0,0,0,1]

clf = MLPClassifier(solver='lbfgs', activation='logistic', alpha=1e-5, hidden_layer_sizes=(2),max_iter=100,random_state=1)
clf.fit(train_x, train_y)
y=clf.predict(test_x)
right = 0
num = len(test_x)
for i in range(num):
    if test_y[i]==y[i]:
        right+=1
print("测试数据:",test_x)
print("测试数据结果:",test_y)
print("预测结果:",y)
print("准确度:",right/num)