# No.5
# 有序列表合并
# 姓名:李昊佳

def bubble_sort(l):
    # 冒泡排序
    for i in range(len(l)-1):
        flag = True
        for j in range(len(l)-1,i,-1):
            if l[j-1]>l[j]:
                temp=l[j]
                l[j]=l[j-1]
                l[j-1]=temp
                flag=False
        if flag:
            break
    return l


def sort_list_slow(l1,l2):
    l3=l1+l2
    bubble_sort(l3)
    return l3

def get_index(arr,num):
    if(len(arr) != 0):
        for i in range(len(arr)):
            if num <= arr[i]:
                return i
        return len(arr)
    else:
        return 0


def sort_list_fast(l1,l2):
    l3=l1.copy()
    for data in l2:
        ind=get_index(l3,data)
        l3.insert(ind,data)
    
    return l3


if __name__=="__main__":
    test_data=[[[1,2,2,4], [1,3,3]],[[1,100], [2,4,8,10]],[[], [1,2,3]],[ [],[] ]]
    right_result=[[1,1,2,2,3,3,4] ,[1,2,4,8,10,100],[1,2,3],[]]
    test_result=[]
    wrong_flag=False
    print("Test data:",test_data)
    for i in range(len(test_data)):
        test_result.append(sort_list_fast(test_data[i][0],test_data[i][1]))
        if test_result[i]!=right_result[i]:
            print(str(test_data[i])+" test error!")
            wrong_flag=True
    print("Test result:",test_result)
    if wrong_flag:
        print("Test finished and funtion error!")
    else:
        print("Test finished and ALL pass!")
