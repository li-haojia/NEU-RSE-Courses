# No.4
# 斐波那契数列
# 姓名:李昊佳

def fibonacci1(x):
    if x <= 0:
        return 0  # error
    elif x <=2:
        return 1
    else:
        x_1 = 1
        x_2 = 1
        for i in range(x-2):
            x_temp=x_1+x_2
            x_2=x_1
            x_1=x_temp
        return x_1

def fibonacci2(x):
    if x <= 0:
        return 0
    elif x <= 2:
        return 1
    else:
        return fibonacci2(x-1)+fibonacci2(x-2)

if __name__=="__main__":
    test_data=[5,6,20]
    right_result=[5,8,6765]
    test_result=[]
    wrong_flag=False
    print("Test data:",test_data)
    for i in range(len(test_data)):
        test_result.append(fibonacci2(test_data[i]))
        if test_result[i]!=right_result[i]:
            print(test_data[i]+" test error!")
            wrong_flag=True
    print("Test result:",test_result)
    if wrong_flag:
        print("Test finished and funtion error!")
    else:
        print("Test finished and ALL pass!")