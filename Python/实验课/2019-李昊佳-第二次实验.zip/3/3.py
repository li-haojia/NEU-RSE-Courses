# No.3
# 回文数
# 姓名:李昊佳

def isPalindrome(x):
    x_abs=abs(x)
    x_string=str(x_abs)
    return x_string==x_string[::-1]

if __name__=="__main__":
    test_data=[123,121,-121,-122]
    right_result=[False,True,True,False]
    test_result=[]
    wrong_flag=False
    print("Test data:",test_data)
    for i in range(len(test_data)):
        test_result.append(isPalindrome(test_data[i]))
        if test_result[i]!=right_result[i]:
            print(test_data[i]+" test error!")
            wrong_flag=True
    print("Test result:",test_result)
    if wrong_flag:
        print("Test finished and funtion error!")
    else:
        print("Test finished and ALL pass!")