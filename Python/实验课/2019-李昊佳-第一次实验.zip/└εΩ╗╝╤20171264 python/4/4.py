# No.4
# 不规则子图
# 姓名:李昊佳
import matplotlib.pyplot as plt
import numpy as np
x=np.linspace(-np.pi,np.pi,100)
plt.figure(figsize=(12,10))
plt.subplot(2,1,1)
y1=np.cos(x)
plt.plot(x,y1)
plt.title('y=cos(x)')
plt.xlabel("X")
plt.ylabel("Y")

plt.subplot(2,3,4)
y2=x.copy()
plt.plot(x,y2)
plt.title('y=x')
plt.xlabel("X")
plt.ylabel("Y")

plt.subplot(2,3,5)
y3=np.sin(x)
plt.plot(x,y3)
plt.title('y=sin(x)')
plt.xlabel("X")
plt.ylabel("Y")

plt.subplot(2,3,6)
y4=np.tan(x)
plt.plot(x,y2)
plt.title('y=tan(x)')
plt.xlabel("X")
plt.ylabel("Y")

plt.show()