# No.1
# 画柱状图，折线图，散点图
# 姓名:李昊佳
import matplotlib.pyplot as plt

data = {'Ch':78, 'Math':81, 'Eh' :82, 'Phy':80, 'Chemi':70}

plt.figure(figsize=(12,4))
plt.subplot(1,3,1)
plt.bar(list(data.keys()),list(data.values()))#注意keys()是方法，最后转化为列表
plt.xlabel("Lesson")
plt.ylabel("Sorce")
plt.subplot(1,3,2)
plt.plot(list(data.values()))
plt.xlabel("Lesson")

plt.subplot(1,3,3)
plt.scatter(list(data.keys()),list(data.values()))
plt.xlabel("Lesson")

plt.show()