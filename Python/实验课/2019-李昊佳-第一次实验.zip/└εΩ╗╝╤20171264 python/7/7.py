# No.7
# KNN
# 姓名:李昊佳
from sklearn.datasets import load_iris
import numpy as np
import matplotlib.pyplot as plt
#knn类
class KnnClassifier():
    def __init__(self,dataset,target):
        self.target=np.array(target)
        self.dataset=np.array(dataset)

    def predict(self,testdata,k):
        # disttemp=(self.dataset-testdata)**2
        # distances=np.sqrt(disttemp.sum(axis=1))
        #利用范数求欧式距离
        distances=np.linalg.norm(self.dataset-testdata,axis=1)
        #对距离排序
        sortind=distances.argsort()
        #选出前k个
        sortind_k=sortind[:k]
        #利用字典统计出现个数
        counter={}
        for index in sortind_k:
            item=self.target[index]
            counter[item]=counter.get(item,0)+1
        # print(counter)
        return(max(counter,key=counter.get))

if __name__=="__main__":
    print("K-NearestNeighbor")
    iris = load_iris()

    X = np.array(iris.data)
    Y = np.array(iris.target)
    #注意打乱数据集，不然传入的数据不全
    rand_ind=np.random.permutation(X.shape[0])
    X_rand=X[rand_ind]
    Y_rand=Y[rand_ind]
    
    train_dataset=X_rand[:75]
    train_target=Y_rand[:75]
    print("训练集大小:",train_dataset.shape[0])
    #测试数据集
    test_dataset=X_rand[75:]
    test_target=Y_rand[75:]
    print("测试集大小:",test_dataset.shape[0])
    K=4
    testnum=test_target.shape[0]
    right_num=0
    wrong_num=0
    #加载数据
    knn=KnnClassifier(train_dataset,train_target)

    #测试性能
    for i in range(0,testnum):
        result=knn.predict(test_dataset[i],K)
        if(result==test_target[i]):
            right_num+=1
        else :
            wrong_num+=1
    
    print("正确率",right_num/testnum)


    # %%绘制准确率与K的关系
    x=np.arange(1,50)
    y=[]
    for kk in range(1,50):
        right_num=0
        wrong_num=0
        for i in range(0,testnum):
            result=knn.predict(test_dataset[i],kk)
            if(result==test_target[i]):
                right_num+=1
            else :
                wrong_num+=1
        y.append(right_num/testnum)
    plt.plot(x,y)
    plt.title("KNN acc and k")
    plt.ylabel("acc")
    plt.xlabel("K")
    plt.show()