# No.2
# 画函数
# 姓名:李昊佳
import matplotlib.pyplot as plt
import numpy as np

x=np.arange(0,2,0.001)
y=np.sin(x)+x*np.exp(-x**2)+x*np.log(x+2)
plt.plot(x,y)
plt.grid(True)
plt.xlabel('X')
plt.ylabel("Y")
plt.title("y=sinx+x*exp(-x^2)+x*ln(x+2)")
plt.show()
