# No.6
# 数据集画图
# 姓名:李昊佳
from sklearn.datasets import load_iris
import numpy as np
import matplotlib.pyplot as plt
iris = load_iris()
y_lable=["Setosa" , "Versicolour" , "Virginica"]
x_lable=["sepal_length","sepal_width","petal_length","petal_width"]

X = np.array(iris.data)
Y = np.array(iris.target)

plt.figure(figsize=(8,16))
plt.subplot(2,1,1)
for i in range(0,len(y_lable)):
    x=X[Y==i,:2]
    plt.scatter(x[:,0],x[:,1],label=y_lable[i])
plt.xlabel("sepal_length")
plt.ylabel("sepal_width")
plt.title("Sepal")
plt.legend()

plt.subplot(2,1,2)
for i in range(0,len(y_lable)):
    x=X[Y==i]
    plt.scatter(x[:,0]*x[:,1],x[:,2]*x[:,3],label=y_lable[i])
plt.xlabel("sepal_length*sepal_width")
plt.ylabel("petal_length*petal_width")
plt.title("Sepal and Petal")
plt.legend()

plt.show()