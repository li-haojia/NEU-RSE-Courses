# No.5
# 多组数据
# 姓名:李昊佳
import matplotlib.pyplot as plt
import numpy as np
x=np.linspace(-np.pi,np.pi,100)
y1=x+5
y2=np.sin(x)+x
y3=np.cos(x)
plt.figure()
plt.plot(x,y1,color='red',label='y=x+5',linestyle = ':')
plt.plot(x,y2,color='g',label='y=sin(x)+x',linestyle = '-.')
plt.plot(x,y3,color='b',label='y=cos(x)')
plt.title("PLOT MATH")
plt.legend()
plt.show()