# No.3
# 画曲面
# 姓名:李昊佳
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.axes3d import Axes3D
import numpy as np

x,y=np.meshgrid(np.linspace(-6,6,100),np.linspace(-6,6,100))
z=np.sin(np.sqrt(2*x**2+2*y**2))+np.sin(x)+x
plt.figure(figsize=(12,8))
axes = plt.subplot(projection='3d')
p = axes.plot_surface(x, y, z,cmap='rainbow')
plt.colorbar(p,shrink=0.5)
plt.show()