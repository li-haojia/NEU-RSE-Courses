#include <stdio.h>
#include <unistd.h>
//#include <pthread.h>
#include <semaphore.h>
#include<fcntl.h> 
#include <sys/sem.h>
void functionA();
void functionB();

int main(int argc, char const *argv[])
{
    pid_t fpid;
    fpid=fork();
    if(0 == fpid)
    {
        printf("I am the child process, my id is %d\n",getpid());
        functionB();
    }
    else if(fpid > 0)
    {
        printf("I am father,and my child is %d, my id is %d\n",fpid,getpid());
        functionA();
    }
    
    return 0;
}

void functionA()
{

    sem_t* sem_rd = sem_open("sem_b_a",O_CREAT,0644,0);// name mode 权限 value
    if(sem_rd==NULL)
    {
        printf("Sem open error!\n");
    }

    sem_t* sem_wr = sem_open("sem_a_b",O_CREAT,0644,0);// name mode 权限 value
    if(sem_wr==NULL)
    {
        printf("Sem open error!\n");
    }

    int lost_counter = 0;

    while(1)
    {
        if(sem_trywait(sem_rd)<0)
        {
            
            lost_counter++;
            printf("B seems to be killed.\n");
            if(lost_counter > 5)
            {
                printf("B is killed!Restart!\n");
                pid_t fpid;
                fpid=fork();
                if(fpid==0)
                {
                    printf("B is Restarted.\n");
                    functionB();
                }
                else if(fpid<0)
                {
                    printf("Restart ERROR!\n");
                }
                    
            }
        }
        else 
        {
            while(sem_trywait(sem_rd)>0);
            lost_counter=0;
            printf("I am A, id is %d. B is active.\n",getpid());
        }
        
        sem_post(sem_wr);
        sleep(1);
    }
    sem_close(sem_wr);
    sem_close(sem_rd);

}
void functionB()
{
    sem_t* sem_rd = sem_open("sem_a_b",O_CREAT,0644,0);// name mode 权限 value
    if(sem_rd==NULL)
    {
        printf("Sem open error!\n");
    }

    sem_t* sem_wr = sem_open("sem_b_a",O_CREAT,0644,0);// name mode 权限 value
    if(sem_wr==NULL)
    {
        printf("Sem open error!\n");
    }

    int lost_counter = 0;

    while(1)
    {
        if(sem_trywait(sem_rd)<0)
        {
            
            lost_counter++;
            printf("A seems to be killed.\n");
            if(lost_counter > 5)
            {
                printf("A is killed!Restart!\n");
                pid_t fpid;
                fpid=fork();
                if(fpid==0)
                {
                    printf("A is Restarted.\n");
                    functionA();
                }
                else if(fpid<0)
                {
                    printf("Restart ERROR!\n");
                }
                    
            }
        }
        else 
        {
            while(sem_trywait(sem_rd)>0);
            lost_counter=0;
            printf("I am B, id is %d.A is active.\n",getpid());
        }
        sem_post(sem_wr);
        sleep(1);
    }
    sem_close(sem_wr);
    sem_close(sem_rd);

}
