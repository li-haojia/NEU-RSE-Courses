function [ T ] = dynamics_parameter_line_min1( q,qd,qdd )

offset2=-pi/2;
s1=sin(q(1)); c1=cos(q(1)); 
s2=sin(q(2)+offset2); c2=cos(q(2)+offset2);
s3=sin(q(3)); c3=cos(q(3));
s4=sin(q(4)); c4=cos(q(4));
s5=sin(q(5)); c5=cos(q(5));
s6=sin(q(6)); c6=cos(q(6));

Q11=qd(1);  Q21=qd(2);  Q31=qd(3);  Q41=qd(4);  Q51=qd(5);  Q61=qd(6); 
Q12=qdd(1);  Q22=qdd(2);  Q32=qdd(3);  Q42=qdd(4);  Q52=qdd(5);  Q62=qdd(6);
f71=0;  f72=0;  f73=0;  n71=0;  n72=0;  n73=0;

d1=evalin('base','dd1');a1=evalin('base','da1');a2=evalin('base','da2');a3=evalin('base','da3');d4=evalin('base','dd4');dt=evalin('base','ddt');
g=evalin('base','dg'); 
W_min=evalin('base','W_min');
P_min=evalin('base','P_min');
W_mins=eval(subs(W_min,{'s1','c1','s2', 'c2','s3', 'c3','s4', 'c4','s5', 'c5','s6', 'c6',...
            'Q11','Q21','Q31', 'Q41','Q51','Q61',...
            'Q12','Q22','Q32', 'Q42','Q52','Q62',...
            'f71','f72','f73', 'n71','n72','n73',...
            'g','d1','a1','a2','a3','d4','dt'},...
            {s1,c1,s2,c2,s3,c3,s4,c4,s5,c5,s6,c6,...
            Q11,Q21,Q31,Q41,Q51,Q61,...
            Q12,Q22,Q32,Q42,Q52,Q62,...
            f71,f72,f73,n71,n72,n73,...
            g,d1,a1,a2,a3,d4,dt}));
        
T=W_mins*P_min;   

end

