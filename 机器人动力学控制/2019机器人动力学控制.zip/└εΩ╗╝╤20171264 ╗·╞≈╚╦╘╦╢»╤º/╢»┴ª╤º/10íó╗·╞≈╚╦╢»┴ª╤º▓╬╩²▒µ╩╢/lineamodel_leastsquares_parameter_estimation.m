%��С���˹�����С������


function P=lineamodel_leastsquares_parameter_estimation()

q_filer_after=evalin('base','q_filer_after');
qd_filer_after=evalin('base','qd_filer_after');
qdd_filer_after=evalin('base','qdd_filer_after');
t_filer_after=evalin('base','t_filer_after');
n=length(q_filer_after);%��������
add_num=1;
offset2=-pi/2;


f71=0;  f72=0;  f73=0;  n71=0;  n72=0;  n73=0;

d1=evalin('base','dd1');a1=evalin('base','da1');a2=evalin('base','da2');a3=evalin('base','da3');d4=evalin('base','dd4');dt=evalin('base','ddt');
g=evalin('base','dg');
param_min_num=evalin('base','param_min_num');
W_min=evalin('base','W_min');
ww=zeros(n*6,param_min_num);
TT=zeros(n*6,1);
m=0;
size(ww)
for k=1:add_num:n
%#####################################################
k
q=q_filer_after(k,:);
qd=qd_filer_after(k,:);
qdd=qdd_filer_after(k,:);
%#####################################################

s1=sin(q(1)); c1=cos(q(1)); 
s2=sin(q(2)+offset2); c2=cos(q(2)+offset2);
s3=sin(q(3)); c3=cos(q(3));
s4=sin(q(4)); c4=cos(q(4));
s5=sin(q(5)); c5=cos(q(5));
s6=sin(q(6)); c6=cos(q(6));

Q11=qd(1);  Q21=qd(2);  Q31=qd(3);  Q41=qd(4);  Q51=qd(5);  Q61=qd(6); 
Q12=qdd(1);  Q22=qdd(2);  Q32=qdd(3);  Q42=qdd(4);  Q52=qdd(5);  Q62=qdd(6);

row1=(1+(k-1)*6);
row2=(6+(k-1)*6);
ww(row1:row2,:)=eval(subs(W_min,{'s1','c1','s2', 'c2','s3', 'c3','s4', 'c4','s5', 'c5','s6', 'c6',...
            'Q11','Q21','Q31', 'Q41','Q51','Q61',...
            'Q12','Q22','Q32', 'Q42','Q52','Q62',...
            'f71','f72','f73', 'n71','n72','n73',...
            'g','d1','a1','a2','a3','d4','dt'},...
            {s1,c1,s2,c2,s3,c3,s4,c4,s5,c5,s6,c6,...
            Q11,Q21,Q31,Q41,Q51,Q61,...
            Q12,Q22,Q32,Q42,Q52,Q62,...
            f71,f72,f73,n71,n72,n73,...
            g,d1,a1,a2,a3,d4,dt}));
        
TT(row1:row2,1)=t_filer_after(k,:)';
%     m=fix(k/6);
%     ww((1+m*6):(6+m*6),:)=W_min_;
%     TT((1+m*6):(6+m*6),1)=T;

% if (k==1)
%     ww=W_min_;
%     TT=T;
% else
% 
% %     ww=[ww;W_min_];
% %     TT=[TT;T];
% end
end

P=((ww'*ww)^(-1))*ww'*TT;
assignin('base','P_min',P);

fid=fopen('parameter_min.txt','w');
fprintf(fid,'P_min=[');
for j=1:param_min_num
    fprintf(fid,'%s;',P(j));
end
fprintf(fid,'];');
end