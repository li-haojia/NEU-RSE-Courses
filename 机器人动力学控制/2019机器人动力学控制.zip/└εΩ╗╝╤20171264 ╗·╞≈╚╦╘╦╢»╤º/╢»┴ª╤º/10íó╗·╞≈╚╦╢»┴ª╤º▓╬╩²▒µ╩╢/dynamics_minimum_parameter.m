
function [ W_min,param_min,param_min_num, R1,R2 ] = dynamics_minimum_parameter()
%d1=342;a1=40;a2=275;a3=25;d4=280;dt=73;g=9802.000;
 d1=evalin('base','dd1');a1=evalin('base','da1');a2=evalin('base','da2');a3=evalin('base','da3');d4=evalin('base','dd4');dt=evalin('base','ddt');
 g=evalin('base','dg');
offset2=-pi/2;

%mi,mci1,mci2,mci3,Ixx,Iyy,Izz,Ixy,Ixz,Iyz,Ia,fv,fc
param_num=evalin('base','param_num');%�ܲ�����Ŀ
param_num_=evalin('base','param_num_');%һ���ؽڲ�����Ŀ

data_num=param_num;
q=zeros(1,6);
qd=zeros(1,6);
qdd=zeros(1,6);

param_min=zeros(1,param_num);
W=evalin('base','W');

for i=1:data_num
    q=unifrnd(-pi,pi,1,6);
    qd=unifrnd(-5*pi,5*pi,1,6);
    qdd=unifrnd(-10*pi,10*pi,1,6);
    
    s1=sin(q(1)); c1=cos(q(1)); 
    s2=sin(q(2)+offset2); c2=cos(q(2)+offset2);
    s3=sin(q(3)); c3=cos(q(3));
    s4=sin(q(4)); c4=cos(q(4));
    s5=sin(q(5)); c5=cos(q(5));
    s6=sin(q(6)); c6=cos(q(6));

    Q11=qd(1);  Q21=qd(2);  Q31=qd(3);  Q41=qd(4);  Q51=qd(5);  Q61=qd(6); 
    Q12=qdd(1);  Q22=qdd(2);  Q32=qdd(3);  Q42=qdd(4);  Q52=qdd(5);  Q62=qdd(6);
    f71=0;  f72=0;  f73=0;  n71=0;  n72=0;  n73=0;

    
     W_=eval(subs(W,{'s1','c1','s2', 'c2','s3', 'c3','s4', 'c4','s5', 'c5','s6', 'c6',...
            'Q11','Q21','Q31', 'Q41','Q51','Q61',...
            'Q12','Q22','Q32', 'Q42','Q52','Q62',...
            'f71','f72','f73', 'n71','n72','n73',...
            'g','d1','a1','a2','a3','d4','dt'},...
            {s1,c1,s2,c2,s3,c3,s4,c4,s5,c5,s6,c6,...
            Q11,Q21,Q31,Q41,Q51,Q61,...
            Q12,Q22,Q32,Q42,Q52,Q62,...
            f71,f72,f73,n71,n72,n73,...
            g,d1,a1,a2,a3,d4,dt}));



    if (i==1)
        WW=W_;
    else 
        WW=[WW;W_];
    end

end


[Q,R]=qr(WW);
param_min_num=0;%������������
for i=1:param_num
   if (abs(R(i,i))<10^(-5))
       param_min(i)=0;
   else
       param_min(i)=1;
       param_min_num=param_min_num+1;
   end
end


W_min=sym(zeros(6,param_min_num));
R1=zeros(param_min_num,param_min_num);
R2=zeros(param_min_num,param_num-param_min_num);
j=1;
j1=1;
for i=1:param_num
   if (1==param_min(i))
      W_min(:,j)=W(:,i);%W�ж�����������ɵľ���
      R1(1:param_min_num,j)=R(1:param_min_num,i);%R�ж�����������ɵľ���
      j=j+1;
   else
      R2(1:param_min_num,j1)=R(1:param_min_num,i);
      j1=j1+1;
   end
end


fid=fopen('aubo_dynamics_parameter_minMatrix.txt','w');

for i=1:6
    for j=1:param_min_num
        fprintf(fid,'w_min%d%d=%s;\r',i,j,char(W_min(i,j)));
    end
end

fclose(fid);



assignin('base','W_min',W_min);
assignin('base','param_min',param_min);
assignin('base','param_min_num',param_min_num);
assignin('base','R1',R1);
assignin('base','R2',R2);
end




