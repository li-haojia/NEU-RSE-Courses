
function estimation_parameter_verify()

q_filer_after=evalin('base','q_filer_after');
qd_filer_after=evalin('base','qd_filer_after');
qdd_filer_after=evalin('base','qdd_filer_after');
t_filer_after=evalin('base','t_filer_after');
traj_Ts=evalin('base','traj_Ts');
n=length(q_filer_after);%��������
T=zeros(n,6);
T_idy=zeros(n,6);

for k=1:1:n
%#####################################################
k
q=q_filer_after(k,:);
qd=qd_filer_after(k,:);
qdd=qdd_filer_after(k,:);

T(k,:)=t_filer_after(k,:);

T_idy(k,:)=dynamics_parameter_line_min1( q,qd,qdd )';

end
data_time=[0:n-1]*traj_Ts;

figure(1)
plot(data_time,T,'b');
hold on
plot(data_time,T_idy,'r');
hold off
figure(2)
plot(data_time,T-T_idy,'g');
end