
%��Լ�����������Ż�����
traj_Ts=0.1;%��������
traj_f=0.05;%tarjectory  fundamental frequency
traj_wf=traj_f*2*pi;%��Ƶ��
traj_n=1/traj_Ts/traj_f;%��������
traj_order=5;%�켣�״�
dof=6;%���߹ؽ���Ŀ


if (1)

    
   opt_x=[-0.019158;0.095312;-0.562811;-0.051102;-0.255859;-0.263255;0.707436;-0.155241;0.130493;0.283588;-0.000166;
-0.106867;-0.115691;-0.015449;-0.024466;0.282189;0.490922;0.001889;0.017575;-0.161662;
-0.275752;-0.047974;-0.000000;0.000000;-0.120814;-0.131721;-0.023693;0.067050;
0.365763;0.161067;-0.221156;-0.116459;-0.084458;-0.025763;0.108338;-0.201827
0.066291;-0.658870;-0.114611;0.318378;-0.225436;0.568183;0.200955;0.277386;-0.146148;0.065289;0.233041;
-0.249373;0.193531;0.117096;-0.504837;0.174108;0.224358;-0.122889;-0.004411;-0.096609;0.684488;
-0.330791;-0.681200;0.056759;-0.102242;0.137908;0.181803;0.232819;0.051425;1.163474];


else
o=zeros(1,10);
o1=zeros(1,6);
opt_q01=[1 0 0 0 0 0];
opt_q02=[0 1 0 0 0 0];
opt_q03=[0 0 1 0 0 0];
opt_q04=[0 0 0 1 0 0];
opt_q05=[0 0 0 0 1 0];
opt_q06=[0 0 0 0 0 1];

%����ʽԼ��
for k=1:1:traj_n-1
    time=k*taj_Ts;
    [opt_q,opt_qd,opt_qdd]=trajectory_function( x,traj_wf,time ,dof, traj_order);

A=[opt_q(1) o o o o o opt_q01;
   opt_qd(1) o o o o o o1;
   opt_qdd(1) o o o o o o1;
   o opt_q(2) o o o o opt_q02;
   o opt_qd(2) o o o o o1;
   o opt_qdd(2) o o o o o1;
   o o opt_q(3) o o o opt_q03;
   o o opt_qd(3) o o o o1;
   o o opt_qdd(3) o o o o1;
   o o o opt_q(4) o o opt_q04;
   o o o opt_qd(4) o o o1;
   o o o opt_qdd(4) o o o1;
   o o o o opt_q(5) o opt_q05;
   o o o o opt_qd(5) o o1;
   o o o o opt_qdd(5) o o1;
   o o o o o opt_q(6) opt_q06;
   o o o o o opt_qd(6) o1;
   o o o o o opt_qdd(6) o1;
   -opt_q(1) o o o o o -opt_q01;
   -opt_qd(1) o o o o o o1;
   -opt_qdd(1) o o o o o o1;
   o -opt_q(2) o o o o -opt_q02;
   o -opt_qd(2) o o o o o1;
   o -opt_qdd(2) o o o o o1;
   o o -opt_q(3) o o o -opt_q03;
   o o -opt_qd(3) o o o o1;
   o o -opt_qdd(3) o o o o1;
   o o o -opt_q(4) o o -opt_q04;
   o o o -opt_qd(4) o o o1;
   o o o -opt_qdd(4) o o o1;
   o o o o -opt_q(5) o -opt_q05;
   o o o o -opt_qd(5) o o1;
   o o o o -opt_qdd(5) o o1;
   o o o o o -opt_q(6) -opt_q06;
   o o o o o -opt_qd(6) o1;
   o o o o o -opt_qdd(6) o1];
%�ؽڽǶȡ����ٶȡ��Ǽ��ٶ�����
b=[2.6180;1.7453;5.2359;2.6180;1.7453;5.2359;2.6180;1.7453;5.2359;2.6180;1.7453;5.2359;2.6180;1.7453;5.2359;2.6180;1.7453;5.2359;
   2.6180;1.7453;5.2359;2.6180;1.7453;5.2359;2.6180;1.7453;5.2359;2.6180;1.7453;5.2359;2.6180;1.7453;5.2359;2.6180;1.7453;5.2359;];


if (k==1)
    AA=A;
    bb=b;
else
    AA=[AA;A];
    bb=[bb;b];
end
end

%��ʽԼ��,ת�ɲ���ʽԼ��
[opt_q0,opt_qd0,opt_qdd0]=trajectory_function( x,traj_wf,0 ,dof, traj_order);
[opt_qn,opt_qdn,opt_qddn]=trajectory_function( x,traj_wf,traj_n*traj_Ts ,dof, traj_order);

Aeq=[opt_q0(1) o o o o o opt_q01;
   opt_qd0(1) o o o o o o1;
   opt_qdd0(1) o o o o o o1;
   o opt_q0(2) o o o o opt_q02;
   o opt_qd0(2) o o o o o1;
   o opt_qdd0(2) o o o o o1;
   o o opt_q0(3) o o o opt_q03;
   o o opt_qd0(3) o o o o1;
   o o opt_qdd0(3) o o o o1;
   o o o opt_q0(4) o o opt_q04;
   o o o opt_qd0(4) o o o1;
   o o o opt_qdd0(4) o o o1;
   o o o o opt_q0(5) o opt_q05;
   o o o o opt_qd0(5) o o1;
   o o o o opt_qdd0(5) o o1;
   o o o o o opt_q0(6) opt_q06;
   o o o o o opt_qd0(6) o1;
   o o o o o opt_qdd0(6) o1;
   opt_qn(1) o o o o o opt_q01;
   opt_qdn(1) o o o o o o1;
   opt_qddn(1) o o o o o o1;
   o opt_qn(2) o o o o opt_q02;
   o opt_qdn(2) o o o o o1;
   o opt_qddn(2) o o o o o1;
   o o opt_qn(3) o o o opt_q03;
   o o opt_qdn(3) o o o o1;
   o o opt_qddn(3) o o o o1;
   o o o opt_qn(4) o o opt_q04;
   o o o opt_qdn(4) o o o1;
   o o o opt_qddn(4) o o o1;
   o o o o opt_qn(5) o opt_q05;
   o o o o opt_qdn(5) o o1;
   o o o o opt_qddn(5) o o1;
   o o o o o opt_qn(6) opt_q06;
   o o o o o opt_qdn(6) o1;
   o o o o o opt_qddn(6) o1];

Aeq_=[-opt_q0(1) o o o o o -opt_q01;
   -opt_qd0(1) o o o o o o1;
   -opt_qdd0(1) o o o o o o1;
   o -opt_q0(2) o o o o -opt_q02;
   o -opt_qd0(2) o o o o o1;
   o -opt_qdd0(2) o o o o o1;
   o o -opt_q0(3) o o o -opt_q03;
   o o -opt_qd0(3) o o o o1;
   o o -opt_qdd0(3) o o o o1;
   o o o -opt_q0(4) o o -opt_q04;
   o o o -opt_qd0(4) o o o1;
   o o o -opt_qdd0(4) o o o1;
   o o o o -opt_q0(5) o -opt_q05;
   o o o o -opt_qd0(5) o o1;
   o o o o -opt_qdd0(5) o o1;
   o o o o o -opt_q0(6) -opt_q06;
   o o o o o -opt_qd0(6) o1;
   o o o o o -opt_qdd0(6) o1;
   -opt_qn(1) o o o o o -opt_q01;
   -opt_qdn(1) o o o o o o1;
   -opt_qddn(1) o o o o o o1;
   o -opt_qn(2) o o o o -opt_q02;
   o -opt_qdn(2) o o o o o1;
   o -opt_qddn(2) o o o o o1;
   o o -opt_qn(3) o o o -opt_q03;
   o o -opt_qdn(3) o o o o1;
   o o -opt_qddn(3) o o o o1;
   o o o -opt_qn(4) o o -opt_q04;
   o o o -opt_qdn(4) o o o1;
   o o o -opt_qddn(4) o o o1;
   o o o o -opt_qn(5) o -opt_q05;
   o o o o -opt_qdn(5) o o1;
   o o o o -opt_qddn(5) o o1;
   o o o o o -opt_qn(6) -opt_q06;
   o o o o o -opt_qdn(6) o1;
   o o o o o -opt_qddn(6) o1];

beq=0.00001*ones(36,1);
beq_=0.00001*ones(36,1);

%���
opt_x0=zeros(66,1)+0.1;%0.1;
[opt_x,opt_fval]=fmincon(@Optimaltrajectory_object_fun,opt_x0,AA,bb,Aeq,beq);

end

%���Թ켣

opt_x_test=[-0.012288;-0.029649;-0.343208;-0.027102;0.717194;0.323852;0.152810;0.315100;-0.514407;-0.429614;0.183254;0.027949;0.014064;0.009131;0.034001;-0.123161;-0.195532;-0.132632;0.158612;0.218812;-0.025920;
0.001234;0.007808;-0.006874;0.000000;-0.000000;-0.021050;0.003619;0.037601;0.190889;-0.024259;-0.153571;0.035998;-0.000000;-0.000000;-0.595319;-0.107254;-0.416137;0.387433;
0.168507;-0.200743;0.843049;-0.029027;0.062054;-0.004060;-0.003396;-0.231206;0.237244;-0.338051;-0.134932;0.171341;0.359519;0.402076;
-0.300938;0.318022;0.043990;0.455623;-0.275541;0.241416;-0.544524;0.017589;0.501151;0.096207;0.275025;-0.275273;1.754596];


%��ͼ
Optimaltrajectory_plot();
