
function qd_filer_after=angular_filtering(n,ws,wc,q_filer_after)

wn=wc/(ws/2);%��ֹƵ��
[b,a]=butter(n,wn,'low');%���ͨ�˲���ϵ��

Ts=1/ws;
ln=length(q_filer_after(:,1));
qd_filer_before=zeros(ln,6);

for k=2:ln-1
    qd_filer_before(k,:)= (q_filer_after(k+1,:)-q_filer_after(k-1,:))/(2*Ts);
end
qd_filer_before(1,:)=qd_filer_before(2,:);
qd_filer_before(ln,:)=qd_filer_before(ln-1,:);

qd_filer_after=filtfilt(b,a,qd_filer_before);


%��ͼ
for i=1:6
figure(i+6)
plot(qd_filer_before(:,i),'g');
title('�ؽ��ٶ�')
hold on
plot(qd_filer_after(:,i),'r');
hold off
end

end

