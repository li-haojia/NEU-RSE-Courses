function Optimaltrajectory_plot() 

traj_Ts=evalin('base','traj_Ts');
traj_wf=evalin('base','traj_wf');
traj_n=evalin('base','traj_n');
traj_order=evalin('base','traj_order');
dof=evalin('base','dof');
x=evalin('base','opt_x');
opt_q=zeros(traj_n,dof);
opt_qd=zeros(traj_n,dof);
opt_qdd=zeros(traj_n,dof);

for k=1:1:traj_n
    time=(k-1)*traj_Ts;
    [opt_q(k,:),opt_qd(k,:),opt_qdd(k,:)]=trajectory_function( x,traj_wf,time ,dof, traj_order);
end

xx=[0:traj_n-1]*traj_Ts;
figure(1)
plot(xx,opt_q(:,1),'r',xx,opt_q(:,2),'c',xx,opt_q(:,3),'y',xx,opt_q(:,4),'g',xx,opt_q(:,5),'b',xx,opt_q(:,6),'m');
figure(2)
plot(xx,opt_qd(:,1),'r',xx,opt_qd(:,2),'c',xx,opt_qd(:,3),'y',xx,opt_qd(:,4),'g',xx,opt_qd(:,5),'b',xx,opt_qd(:,6),'m');
figure(3)
plot(xx,opt_qdd(:,1),'r',xx,opt_qdd(:,2),'c',xx,opt_qdd(:,3),'y',xx,opt_qdd(:,4),'g',xx,opt_qdd(:,5),'b',xx,opt_qdd(:,6),'m');

end