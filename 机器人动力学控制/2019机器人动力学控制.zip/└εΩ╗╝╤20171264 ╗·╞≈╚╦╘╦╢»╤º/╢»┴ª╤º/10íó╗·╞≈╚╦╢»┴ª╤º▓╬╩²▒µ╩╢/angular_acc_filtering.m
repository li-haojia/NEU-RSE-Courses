
function qdd_filer_after=angular_acc_filtering(n,ws,wc,qd_filer_after)

wn=wc/(ws/2);%��ֹƵ��
[b,a]=butter(n,wn,'low');%���ͨ�˲���ϵ��

Ts=1/ws;
ln=length(qd_filer_after(:,1));

qdd_filer_before=zeros(ln:6);
for k=2:ln-1
    qdd_filer_before(k,:)= (qd_filer_after(k+1,:)-qd_filer_after(k-1,:))/(2*Ts);
end
qdd_filer_before(1,:)=qdd_filer_before(2,:);
qdd_filer_before(ln,:)=qdd_filer_before(ln-1,:);

qdd_filer_after=filtfilt(b,a,qdd_filer_before);
% qdd_filer_after=smooth(qdd_filer_before,'rloess');

%��ͼ
for i=1:6
figure(i+12)
plot(qdd_filer_before(:,i),'g');
title('�ؽڼ��ٶ�')
hold on
plot(qdd_filer_after(:,i),'r');
hold off
end

end

