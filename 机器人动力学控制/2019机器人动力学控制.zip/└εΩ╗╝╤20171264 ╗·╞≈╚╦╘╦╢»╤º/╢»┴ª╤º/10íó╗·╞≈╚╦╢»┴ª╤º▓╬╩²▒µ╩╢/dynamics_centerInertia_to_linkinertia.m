%ת������ѧ���Ĺ������������˹�������

syms Io111  Io122  Io133  Io112  Io113  Io123  Io211  Io222  Io233  Io212  Io213  Io223  Io311  Io322  Io333  Io312  Io313  Io323  Io411  Io422  Io433  Io412  Io413  Io423  Io511  Io522  Io533  Io512  Io513  Io523  Io611  Io622  Io633  Io612  Io613  Io623 real;%������˹��Ծ�

I=[1 0 0;0 1 0;0 0 1];
Pc1=[mc11;mc12;mc13];Pc2=[mc21;mc22;mc23];Pc3=[mc31;mc32;mc33];Pc4=[mc41;mc42;mc43];Pc5=[mc51;mc52;mc53];Pc6=[mc61;mc62;mc63];%����λ��
Io1=[Io111 Io112 Io113;Io112 Io122 Io123;Io113 Io123 Io133];Io2=[Io211 Io212 Io213;Io212 Io222 Io223;Io213 Io223 Io233];Io3=[Io311 Io312 Io313;Io312 Io322 Io323;Io313 Io323 Io333];Io4=[Io411 Io412 Io413;Io412 Io422 Io423;Io413 Io423 Io433];Io5=[Io511 Io512 Io513;Io512 Io522 Io523;Io513 Io523 Io533];Io6=[Io611 Io612 Io613;Io612 Io622 Io623;Io613 Io623 Io633];%�ο����������ĵĹ�������
Ic1=Io1-m1*(Pc1'*Pc1*I-Pc1*Pc1');
Ic2=Io2-m2*(Pc2'*Pc2*I-Pc2*Pc2');
Ic3=Io3-m3*(Pc3'*Pc3*I-Pc3*Pc3');
Ic4=Io4-m4*(Pc4'*Pc4*I-Pc4*Pc4');
Ic5=Io5-m5*(Pc5'*Pc5*I-Pc5*Pc5');
Ic6=Io6-m6*(Pc6'*Pc6*I-Pc6*Pc6');

Q_=zeros(6,1);

T_linkInertia=subs(TNE,{'Ic111','Ic122','Ic133','Ic112','Ic113','Ic123','Ic211','Ic222','Ic233','Ic212','Ic213','Ic223','Ic311','Ic322','Ic333','Ic312','Ic313','Ic323','Ic411','Ic422','Ic433','Ic412','Ic413','Ic423','Ic511','Ic522','Ic533','Ic512','Ic513','Ic523','Ic611','Ic622','Ic633','Ic612','Ic613','Ic623'},...
    {Ic1(1,1),Ic1(2,2),Ic1(3,3),Ic1(1,2),Ic1(1,3),Ic1(2,3),Ic2(1,1),Ic2(2,2),Ic2(3,3),Ic2(1,2),Ic2(1,3),Ic2(2,3),Ic3(1,1),Ic3(2,2),Ic3(3,3),Ic3(1,2),Ic3(1,3),Ic3(2,3),Ic4(1,1),Ic4(2,2),Ic4(3,3),Ic4(1,2),Ic4(1,3),Ic4(2,3),Ic5(1,1),Ic5(2,2),Ic5(3,3),Ic5(1,2),Ic5(1,3),Ic5(2,3),Ic6(1,1),Ic6(2,2),Ic6(3,3),Ic6(1,2),Ic6(1,3),Ic6(2,3)});

fid=fopen('dynamics_linkInertiaResult.txt','w');
fprintf(fid,'T1=%s\rT2=%s\rT3=%s\rT4=%s\rT5=%s\rT6=%s\r',char(T_linkInertia(1)),char(T_linkInertia(2)),char(T_linkInertia(3)),char(T_linkInertia(4)),char(T_linkInertia(5)),char(T_linkInertia(6)));
fclose(fid);

