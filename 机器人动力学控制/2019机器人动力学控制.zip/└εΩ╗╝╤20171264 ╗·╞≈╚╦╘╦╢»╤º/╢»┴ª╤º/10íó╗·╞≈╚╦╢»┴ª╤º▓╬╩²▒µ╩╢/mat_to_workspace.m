tmp=load('q_filer_before.mat');
q_filer_before=tmp.ans(2:end,:)';
tmp=load('t_filer_before.mat');
t_filer_before=tmp.ans(2:end,:)';