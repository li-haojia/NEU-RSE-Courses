%�Ƶ�aubo����ѧ
syms s1 c1  s2  c2  s3  c3  s4  c4  s5  c5  s6  c6  d1 a1 a2 a3 d4 dt real;%a6Ϊ����ϵ6�붨������ϵ֮��ľ���
syms Q11  Q21  Q31  Q41  Q51  Q61 real;
syms Q12  Q22  Q32  Q42  Q52  Q62 real;
syms mc11  mc12  mc13  mc21  mc22  mc23  mc31  mc32  mc33  mc41  mc42  mc43  mc51  mc52  mc53  mc61  mc62  mc63 real;%����λ��
syms Ic111  Ic122  Ic133  Ic112  Ic113  Ic123  Ic211  Ic222  Ic233  Ic212  Ic213  Ic223  Ic311  Ic322  Ic333  Ic312  Ic313  Ic323  Ic411  Ic422  Ic433  Ic412  Ic413  Ic423  Ic511  Ic522  Ic533  Ic512  Ic513  Ic523  Ic611  Ic622  Ic633  Ic612  Ic613  Ic623 real;%���Ծ�
syms m1  m2  m3  m4  m5  m6 real;
syms f71  f72  f73  n71  n72  n73 real;
syms g real;

syms Ia1 Ia2 Ia3 Ia4 Ia5 Ia6;%�ؽڹ���
syms fv1 fc1 fv2 fc2 fv3 fc3 fv4 fc4 fv5 fc5 fv6 fc6;%ճ��Ħ��,����Ħ��



R01=[c1 -s1 0;
    s1 c1 0;
    0 0 1];
R12=[c2 -s2 0;
    0 0 1;
    -s2 -c2 0];
R23=[c3 -s3 0;
    s3 c3 0;
    0 0 1];
R34=[c4 -s4 0;
    0 0 1;
    -s4 -c4 0];
R45=[c5 -s5 0;
    0 0 -1;
    s5 c5 0];
R56=[c6 -s6 0;
    0 0 1;
    -s6 -c6 0];
R06=R01*R12*R23*R34*R45*R56;
R10=R01';R21=R12';R32=R23';R43=R34';R54=R45';R65=R56';
%R67=eye(3);

QZ1=[0;0;Q11];QZ2=[0;0;Q21];QZ3=[0;0;Q31];QZ4=[0;0;Q41];QZ5=[0;0;Q51];QZ6=[0;0;Q61];
QZ11=[0;0;Q12];QZ21=[0;0;Q22];QZ31=[0;0;Q32];QZ41=[0;0;Q42];QZ51=[0;0;Q52];QZ61=[0;0;Q62];
P01=[0;0;d1];P12=[a1;0;0];P23=[a2;0;0];P34=[a3;d4;0];P45=[0;0;0];P56=[0;0;0];P67=[0;0;dt];%��һ������ϵԭ���ڵ�ǰ����ϵ��λ��
Pc1=[mc11;mc12;mc13];Pc2=[mc21;mc22;mc23];Pc3=[mc31;mc32;mc33];Pc4=[mc41;mc42;mc43];Pc5=[mc51;mc52;mc53];Pc6=[mc61;mc62;mc63];%����λ��
Ic1=[Ic111 Ic112 Ic113;Ic112 Ic122 Ic123;Ic113 Ic123 Ic133];Ic2=[Ic211 Ic212 Ic213;Ic212 Ic222 Ic223;Ic213 Ic223 Ic233];Ic3=[Ic311 Ic312 Ic313;Ic312 Ic322 Ic323;Ic313 Ic323 Ic333];Ic4=[Ic411 Ic412 Ic413;Ic412 Ic422 Ic423;Ic413 Ic423 Ic433];Ic5=[Ic511 Ic512 Ic513;Ic512 Ic522 Ic523;Ic513 Ic523 Ic533];Ic6=[Ic611 Ic612 Ic613;Ic612 Ic622 Ic623;Ic613 Ic623 Ic633];%�ο����������ĵĹ�������
f7=[f71;f72;f73];n7=[n71;n72;n73];


w0=[0;0;0];%�������ٶ�
w01=[0;0;0];%�����Ǽ��ٶ�
v01=[0;0;g];%��������Ӱ��

%�ٶȡ����ٶ��������
w1=R10*w0+QZ1;
w11=R10*w01+cross(R10*w0,QZ1)+QZ11;
v11=R10*(cross(w01,P01)+cross(w0,cross(w0,P01))+v01);
vc11=cross(w11,Pc1)+cross(w1,cross(w1,Pc1))+v11;
F1=m1*vc11;
N1=Ic1*w11+cross(w1,Ic1*w1);

w2=R21*w1+QZ2;
w21=R21*w11+cross(R21*w1,QZ2)+QZ21;
v21=R21*(cross(w11,P12)+cross(w1,cross(w1,P12))+v11);
vc21=cross(w21,Pc2)+cross(w2,cross(w2,Pc2))+v21;
F2=m2*vc21;
N2=Ic2*w21+cross(w2,Ic2*w2);

w3=R32*w2+QZ3;
w31=R32*w21+cross(R32*w2,QZ3)+QZ31;
v31=R32*(cross(w21,P23)+cross(w2,cross(w2,P23))+v21);
vc31=cross(w31,Pc3)+cross(w3,cross(w3,Pc3))+v31;
F3=m3*vc31;
N3=Ic3*w31+cross(w3,Ic3*w3);

w4=R43*w3+QZ4;
w41=R43*w31+cross(R43*w3,QZ4)+QZ41;
v41=R43*(cross(w31,P34)+cross(w3,cross(w3,P34))+v31);
vc41=cross(w41,Pc4)+cross(w4,cross(w4,Pc4))+v41;
F4=m4*vc41;
N4=Ic4*w41+cross(w4,Ic4*w4);

w5=R54*w4+QZ5;
w51=R54*w41+cross(R54*w4,QZ5)+QZ51;
v51=R54*(cross(w41,P45)+cross(w4,cross(w4,P45))+v41);
vc51=cross(w51,Pc5)+cross(w5,cross(w5,Pc5))+v51;
F5=m5*vc51;
N5=Ic5*w51+cross(w5,Ic5*w5);

w6=R65*w5+QZ6;
w61=R65*w51+cross(R65*w5,QZ6)+QZ61;
v61=R65*(cross(w51,P56)+cross(w5,cross(w5,P56))+v51);
vc61=cross(w61,Pc6)+cross(w6,cross(w6,Pc6))+v61;
F6=m6*vc61;
N6=Ic6*w61+cross(w6,Ic6*w6);

%�����������ڵ���
f6=f7+F6;
n6=N6+n7+cross(Pc6,F6)+cross(P67,f7);
T6=n6'*[0;0;1];

f5=R56*f6+F5;
n5=N5+R56*n6+cross(Pc5,F5)+cross(P56,R56*f6);
T5=n5'*[0;0;1];

f4=R45*f5+F4;
n4=N4+R45*n5+cross(Pc4,F4)+cross(P45,R45*f5);
T4=n4'*[0;0;1];

f3=R34*f4+F3;
n3=N3+R34*n4+cross(Pc3,F3)+cross(P34,R34*f4);
T3=n3'*[0;0;1];

f2=R23*f3+F2;
n2=N2+R23*n3+cross(Pc2,F2)+cross(P23,R23*f3);
T2=n2'*[0;0;1];

f1=R12*f2+F1;
n1=N1+R12*n2+cross(Pc1,F1)+cross(P12,R12*f2);
T1=n1'*[0;0;1];

%����ؽڹ��Լ�Ħ��ģ��
T1=T1+Ia1*Q12+fv1*Q11+fc1*sign(Q11);
T2=T2+Ia2*Q22+fv2*Q21+fc2*sign(Q21);
T3=T3+Ia3*Q32+fv3*Q31+fc3*sign(Q31);
T4=T4+Ia4*Q42+fv4*Q41+fc4*sign(Q41);
T5=T5+Ia5*Q52+fv5*Q51+fc5*sign(Q51);
T6=T6+Ia6*Q62+fv6*Q61+fc6*sign(Q61);
TNE=[T1;T2;T3;T4;T5;T6];
t1=char(T1);t2=char(T2);t3=char(T3);t4=char(T4);t5=char(T5);t6=char(T6);

fid=fopen('dynamics_full_result.txt','w');
fprintf(fid,'T1=%s\rT2=%s\rT3=%s\rT4=%s\rT5=%s\rT6=%s\r',t1,t2,t3,t4,t5,t6);
fclose(fid);





 


