function [ q,qd,qdd ] = trajectory_function( x,traj_wf,time ,dof, traj_order)
q=zeros(dof,1);
qd=zeros(dof,1);
qdd=zeros(dof,1);
order_2=traj_order*2;
for ii=1:dof
   m=(order_2+1)*(ii-1); 
   q(ii)=x(m+order_2+1);
   for jj=1:5
       q(ii)= q(ii)+((x(m + 2*(jj-1)+1) / (traj_wf * jj))*sin(traj_wf*jj*time) - (x(m + 2*(jj-1)+2) / (traj_wf * jj))*cos(traj_wf*jj*time));
       qd(ii) = qd(ii)+(x(m + 2*(jj-1)+1) *cos(traj_wf*jj*time)+x(m + 2*(jj-1)+2)*sin(traj_wf*jj*time));
       qdd(ii) =qdd(ii)+traj_wf*jj*(-x(m + 2*(jj-1)+1)*sin(traj_wf*jj*time)+x(m + 2*(jj-1)+2)*cos(traj_wf*jj*time));
   end    
end
end

