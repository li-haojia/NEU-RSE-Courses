clc
clear;
% L0=Link([0, 0, 0, 0],'standard'); 
L1=Link([0, 0.342, 0, 0],'standard'); 
L2=Link([0,0,0.04,pi/2],'standard');
L3=Link([pi/2,0,0.275,0],'standard');
L4=Link([0 ,0,0.025,pi/2],'standard');
L5=Link([0 ,0.280,0,-pi/2],'standard');
L6=Link([0 ,0,0,pi/2],'standard');
L7=Link([0 ,0.073,0,0],'standard');
L8=Link([0 ,0,0,0],'standard');

robot=SerialLink([L1,L2,L3,L4,L5,L6,L7,L8]);
robot.name='rokae SDH ��껼�';
robot.display();
%robot.plot([0,0 pi/2 0 0 0 0 0]);
robot.teach();

