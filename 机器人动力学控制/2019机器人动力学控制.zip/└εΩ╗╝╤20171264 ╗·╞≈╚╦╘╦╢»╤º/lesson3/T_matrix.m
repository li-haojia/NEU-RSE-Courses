function m = T_matrix(th,d,a,alpha)
m=zeros(4,4);
ct = cos(th);
st=sin(th);
ca=cos(alpha);
sa=sin(alpha);
m(1,:)=[ct, -st,0,a];
m(2,:)=[st*ca,ct*ca,-sa,-sa*d];
m(3,:)=[st*sa,ct*sa,-ca,ca*d];
m(4,:)=[0,0,0,1];

end

