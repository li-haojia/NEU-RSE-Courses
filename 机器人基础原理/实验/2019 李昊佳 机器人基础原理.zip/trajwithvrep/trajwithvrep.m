%����:PUMA560 DH�����ֶ���ģ���ؽڿռ��˹��滮��Matlab�ѿ����ռ���桢V-REP���Ϸ���
%note: please run puma560.ttt in v-rep first,and start simulating
%author: Li haojia
%data:2019��5��12��

clc; clear;

%puma560 �����˹���
%modified �Ľ���D-H��
L1=Link([0,0,0,0],'modified');
L2=Link([0,0.14909,0,pi/2],'modified');
L3=Link([pi/2, 0,0.4318,0],'modified');
L4=Link([0 ,0.443307,0.02032,pi/2],'modified');
L5=Link([0 ,0,0,pi/2],'modified');
L6=Link([0 ,0.05625,0,pi/2],'modified');

robot=SerialLink([L1,L2,L3,L4,L5,L6]);
robot.name='PUMA 560';
robot.display();
robot.plot([0 0 0 0 0 0]);
%��ʼ�ؽ�λ��
int_ang=[0,0,0,0,0,0];
%Ŀ��ؽ�λ��
targ_ang=[pi/5,pi/3,pi/3,pi/4,-pi/3,pi/2];
%���㲽��
step=150;
%�ؽڿռ�滮
disp('jtraj Program started');
[q,qd,qdd]=jtraj(int_ang,targ_ang,step);
subplot(2,4,3);i=1:6 ;plot(q(:,i));title ('position' );grid on; %λ��
subplot(2,4,4);i=1:6 ;plot(qd(:,i));title ('speed' );grid on;%�ٶ�
subplot(2,4,7);i=1:6 ;plot(qdd(:,i));title ('acc' );grid on;%���ٶ�
%�ѿ����ռ�滮��ʾ
disp('ctraj Program started');
T0=robot.fkine(int_ang);
Tf=robot.fkine(targ_ang);
Tc=ctraj(T0,Tf,step);
Tjtraj=transl(Tc);
subplot(2,4,8);
plot2(Tjtraj);grid on;
subplot(2,4,[1,2,5,6]);

disp('Matlab display');
qq=robot.ikine(Tc);
robot.plot(qq);

disp('V-rep Program started');
% vrep=remApi('remoteApi','extApi.h'); % using the header (requires a compiler)
vrep=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
vrep.simxFinish(-1); % just in case, close all opened connections
clientID=vrep.simxStart('127.0.0.1',19999,true,true,5000,5);

if (clientID>-1)
      disp('Connected to remote API server');
       % get handle for Baxter_rightArm_joint1 
      [res,handle_rightArmjoint1] = vrep.simxGetObjectHandle(clientID,'puma560_joint1',vrep.simx_opmode_oneshot_wait); 
      [res,handle_rightArmjoint2] = vrep.simxGetObjectHandle(clientID,'puma560_joint2',vrep.simx_opmode_oneshot_wait); 
      [res,handle_rightArmjoint3] = vrep.simxGetObjectHandle(clientID,'puma560_joint3',vrep.simx_opmode_oneshot_wait); 
      [res,handle_rightArmjoint4] = vrep.simxGetObjectHandle(clientID,'puma560_joint4',vrep.simx_opmode_oneshot_wait); 
      [res,handle_rightArmjoint5] = vrep.simxGetObjectHandle(clientID,'puma560_joint5',vrep.simx_opmode_oneshot_wait); 
      [res,handle_rightArmjoint6] = vrep.simxGetObjectHandle(clientID,'puma560_joint6',vrep.simx_opmode_oneshot_wait); 
      
%Set the position of every joint
        if(vrep.simxGetConnectionId(clientID) ~= -1)  % while v-rep connection is still active
         for i=1:step
         vrep.simxPauseCommunication(clientID,1);      
         vrep.simxSetJointTargetPosition(clientID,handle_rightArmjoint1,q(i,1),vrep.simx_opmode_oneshot); 
         vrep.simxSetJointTargetPosition(clientID,handle_rightArmjoint2,q(i,2),vrep.simx_opmode_oneshot); 
         vrep.simxSetJointTargetPosition(clientID,handle_rightArmjoint3,q(i,3),vrep.simx_opmode_oneshot); 
         vrep.simxSetJointTargetPosition(clientID,handle_rightArmjoint4,q(i,4),vrep.simx_opmode_oneshot);
         vrep.simxSetJointTargetPosition(clientID,handle_rightArmjoint5,q(i,5),vrep.simx_opmode_oneshot);
         vrep.simxSetJointTargetPosition(clientID,handle_rightArmjoint6,q(i,6),vrep.simx_opmode_oneshot);
         vrep.simxPauseCommunication(clientID,0);
         pause(0.1);
         end
        end  
               
     % Before closing the connection to V-REP, make sure that the last command sent out had time to arrive. You can guarantee this with (for example):
     vrep.simxGetPingTime(clientID);
     % Now close the connection to V-REP:
     vrep.simxFinish(clientID);
else
      disp('Failed connecting to remote API server');
end
   vrep.delete(); % call the destructor!
   
   disp('Program ended');

