b=1; p1=raylcdf(0.2,b); p2=raylcdf(2,b); P1=p2-p1

p1=raylcdf(1,b); P2=1-p1

