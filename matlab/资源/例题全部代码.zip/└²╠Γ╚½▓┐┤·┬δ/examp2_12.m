s=0;
for i=1:100
    s=s+i;
end

s=0; i=1;
while (i<=100)
    s=s+i; i=i+1;
end