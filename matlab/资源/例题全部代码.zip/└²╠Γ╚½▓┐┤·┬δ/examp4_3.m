C=[1 2 3]; R=[3 4 5 6 7 8 9]; H=hankel(C,R)

C=[1 2 3]; H1=hankel(C)