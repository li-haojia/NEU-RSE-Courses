num=[-17,-7,2,1,-1,1]; den=[1,11,48,106,125,75,17];
[r,p,k]=pfrac(num,den); format long e; [r,p]

