syms t w; syms a positive
f=sin(a*t)^2/t; fourier(f,t,w)
