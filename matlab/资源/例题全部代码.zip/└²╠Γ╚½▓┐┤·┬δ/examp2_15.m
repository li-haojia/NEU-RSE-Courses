s=0;
for i=1:10000
    s=s+i; if s>10000, break; end
end