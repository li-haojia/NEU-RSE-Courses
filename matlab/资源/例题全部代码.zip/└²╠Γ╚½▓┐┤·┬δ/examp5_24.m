n=[1,2,3,4]; d=[1,11,48,106,125,75,18]; format long
[r,p,k]=residue(n,d); [n,d1]=rat(r); [n,d1,p]

