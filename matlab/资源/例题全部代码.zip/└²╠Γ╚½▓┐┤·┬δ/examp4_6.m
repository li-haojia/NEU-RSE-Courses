syms a1 a2 a3 a4 a5 a6 a7 a8 a9 a10
A=compan([a1 a2 a3 a4 a5 a6 a7 a8 a9 a10])
