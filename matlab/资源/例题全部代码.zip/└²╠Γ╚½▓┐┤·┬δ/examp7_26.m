[t,y]=fdiff('c7fun5',[0,1],[1,4],50); plot(t,y)
