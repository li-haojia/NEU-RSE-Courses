A=vander([1 2 3 4 5 6 7])

aa=poly(A); B=polyvalm(aa, A);  norm(B)

aa1=poly1(A); B1=polyvalm(aa1, A);  norm(B1)