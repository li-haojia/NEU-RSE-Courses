syms x; int(exp(-x^2/2))

syms a x; int(x*sin(a*x^4)*exp(x^2/2))

