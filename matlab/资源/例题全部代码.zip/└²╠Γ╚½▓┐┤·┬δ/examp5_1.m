syms t; f=t^2*exp(-2*t)*sin(t+pi); laplace(f)

pretty(ans)

latex(ans)