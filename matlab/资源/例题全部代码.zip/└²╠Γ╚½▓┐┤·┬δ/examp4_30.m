A=[1 1; 5*eps,0; 0,5*eps]; rank(A)
