[t,x]=ode15s('c7impode',[0,2],[1,0,0,1]); plot(t,x)

