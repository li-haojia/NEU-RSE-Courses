vpa(pi,300)

vpa(pi)