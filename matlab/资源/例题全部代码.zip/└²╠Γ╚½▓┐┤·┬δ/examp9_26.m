r=gamrnd(1,3,400,1); [H,p,c,d]=jbtest(r,0.05)
