syms t w; syms a potitive
f=1/(t^2+a^2); F=fourier(f,t,w)

syms t w; syms a positive
f=pi*exp(-a*abs(w))/a; ifourier(f)

ifourier(F)
