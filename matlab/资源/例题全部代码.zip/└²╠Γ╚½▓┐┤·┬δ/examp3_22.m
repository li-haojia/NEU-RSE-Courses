format long; sum(2.^[0:63])

sum(sym(2).^[0:200]) % �� syms k; symsum(2^k,0,200)

