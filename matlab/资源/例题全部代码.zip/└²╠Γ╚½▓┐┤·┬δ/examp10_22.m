[a,y,x]=wavefun('db6',2); subplot(141), plot(x,y)
[a,y,x]=wavefun('db6',4); subplot(142), plot(x,y)
[a,y,x]=wavefun('db6',6); subplot(143), plot(x,y)
[a,y,x]=wavefun('db6',8); subplot(144), plot(x,y)
