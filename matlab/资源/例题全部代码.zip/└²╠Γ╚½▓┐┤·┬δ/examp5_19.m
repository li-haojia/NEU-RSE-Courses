syms p q z
for i=1:8
    disp(simple(iztrans(q/(1/z-p)^i)))
end