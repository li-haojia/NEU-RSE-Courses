[m,s]=raylstat(0.45)

