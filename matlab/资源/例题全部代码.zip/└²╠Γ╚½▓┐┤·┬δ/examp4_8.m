tic, A=sym(hilb(20)); det(A), toc
