syms a b x y; [x,y]=solve('x^2+a*x^2+6*b+3*y^2=0','y=a+(x+3)','x,y')

