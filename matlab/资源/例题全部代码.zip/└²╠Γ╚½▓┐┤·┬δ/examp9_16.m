p=randn(30000,4); cov(p)
