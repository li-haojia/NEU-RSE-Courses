ezplot('x^2 *sin(x+y^2) +y^2*exp(x+y)+5*cos(x^2+y)')

ezplot('x^2 *sin(x+y^2) +y^2*exp(x+y)+5*cos(x^2+y)',[-10 10])
