theta=0:0.01:6*pi; rho=5*sin(4*theta/3); polar(theta,rho)

rho=5*sin(theta/3); polar(theta,rho)
