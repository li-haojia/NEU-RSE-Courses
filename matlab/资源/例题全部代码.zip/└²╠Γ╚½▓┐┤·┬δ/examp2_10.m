m=sym(1856120); n=sym(1483720); [gcd(m,n), lcm(m,n)]

factor(lcm(n,m))