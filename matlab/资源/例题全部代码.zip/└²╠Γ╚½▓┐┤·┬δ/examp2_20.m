tic, my_fibo(25), toc

tic, a=[1,1];
for k=3:100, a(k)=a(k-1)+a(k-2); end, toc