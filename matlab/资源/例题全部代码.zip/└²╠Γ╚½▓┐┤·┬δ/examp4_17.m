syms a1 a2 a3 a4; H=hankel([a1 a2 a3 a4]); inv(H)
