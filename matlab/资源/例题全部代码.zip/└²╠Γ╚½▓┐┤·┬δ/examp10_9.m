x=-2:0.01:2; y=tansig(x); plot(x,y)

x=-2:0.01:2; y=logsig(x); plot(x,y)