syms t x
x=dsolve('Dx=x*(1-x^2)')

syms t x;  x=dsolve('Dx=x*(1-x^2)+1')
